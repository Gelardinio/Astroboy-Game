/*
        Add header here
*/
// Motion Parallax
// http://nifty.stanford.edu/2019/dicken-motion-parallax/specification.html
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_primitives.h>

#define SKY         al_map_rgb(0x87, 0xce, 0xfa)
#define MOUNTIAN    al_map_rgb(0x118, 0xff, 0x0a)

using namespace std;

ALLEGRO_DISPLAY *display;
ALLEGRO_TIMER *timer;
ALLEGRO_FONT *arial;
ALLEGRO_EVENT_QUEUE *event_queue;

int initializeAllegro(int width, int height, const char title[]);
void displaySky();
void displayGrass();
void displayFarMountain();
void displayNearMountains();
void displayBirds();

const int screenWidth = 800;
const int screenHeight = 700;

int main() {

    ALLEGRO_EVENT event;

    if (! initializeAllegro(screenWidth, screenHeight, "Your name Motion Parallax")) {
        printf("Allegro failed to initialize\n");
        return 1;
    }

    bool done = false;

    while (!done) {
       al_wait_for_event(event_queue, &event);

       if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
           done = true;
       }
       else if (event.type == ALLEGRO_EVENT_KEY_DOWN) {
           ALLEGRO_KEYBOARD_STATE key_state;
           al_get_keyboard_state(&key_state);
           if (al_key_down(&key_state, ALLEGRO_KEY_ESCAPE))
               done = true;
        }
        else if (event.type == ALLEGRO_EVENT_TIMER) {
            displaySky();
            al_draw_text(arial, al_map_rgb(255, 100, 100), 300, 100, 0, "Name Allegro Scene");
            displayFarMountain();
            displayNearMountains();
            displayGrass();
            displayBirds();
            al_flip_display();
        }

    } // end of main loop
    return 0;
}

void displaySky() {
    al_clear_to_color(SKY);
    al_draw_filled_circle(100,100,50, al_map_rgb(100,100,0));
}


void displayGrass() {
     al_draw_filled_rectangle(0, screenHeight-150,  screenWidth, screenHeight, al_map_rgb(0,200,0));
}

void displayNearMountains() {
    // stub
}

void displayFarMountain() {
   al_draw_filled_triangle(300, 500, 500,  500, 400, 300, MOUNTIAN);
}

// five birds flying across screen
void displayBirds() {
    float x1 = 100, y1 = 150;
    for (int i=0; i<5; i++) {
        al_draw_line(x1+i*25, y1, x1+i*25+50, y1-15, al_map_rgb(0,0,0), 3);
    }
}


